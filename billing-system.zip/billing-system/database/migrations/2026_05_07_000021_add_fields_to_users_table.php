<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // This migration is intentionally left empty.
            // All user fields have been consolidated into
            // 2026_05_08_000001_add_billing_fields_to_users_table.php
            // and 2026_05_07_203611_add_is_admin_to_users_table.php
        });
    }

    public function down(): void
    {
        // No-op: fields are managed by the consolidated migration
    }
};
