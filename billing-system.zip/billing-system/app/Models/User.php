<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'first_name',
        'last_name',
        'email',
        'password',
        'phone',
        'company',
        'address_line1',
        'address_line2',
        'city',
        'state',
        'postal_code',
        'country',
        'status',
        'language',
        'timezone',
        'currency',
        'marketing_emails',
        'is_admin',
        'credit_balance',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'api_token',
    ];

    /**
     * Get attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'two_factor_confirmed_at' => 'datetime',
            'last_login_at' => 'datetime',
            'marketing_emails' => 'boolean',
            'is_admin' => 'boolean',
            'credit_balance' => 'decimal:2',
        ];
    }

    // Relationships
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function creditTransactions(): HasMany
    {
        return $this->hasMany(CreditTransaction::class);
    }

    public function credit(): HasOne
    {
        return $this->hasOne(UserCredit::class);
    }

    public function loginHistory(): HasMany
    {
        return $this->hasMany(LoginHistory::class);
    }

    public function notes(): HasMany
    {
        return $this->hasMany(UserNote::class);
    }


    public function getUnpaidInvoicesCount(): int
    {
        return $this->invoices()->where('status', 'unpaid')->count();
    }

    public function getOverdueInvoicesCount(): int
    {
        return $this->invoices()
            ->where('status', 'unpaid')
            ->whereDate('due_date', '<', now())
            ->count();
    }

    public function getOpenTicketsCount(): int
    {
        return $this->tickets()
            ->whereIn('status', ['open', 'answered', 'customer_reply'])
            ->count();
    }

    public function getActiveServicesCount(): int
    {
        return $this->services()->where('status', 'active')->count();
    }

    public function getCreditBalance(): float
    {
        return (float) ($this->credit_balance ?? 0);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeSuspended($query)
    {
        return $query->where('status', 'suspended');
    }

    public function scopeAdmins($query)
    {
        return $query->where('is_admin', true);
    }

    // Attributes
    public function getFullNameAttribute(): string
    {
        return trim(($this->first_name ?? '') . ' ' . ($this->last_name ?? '')) ?: $this->name;
    }

    public function getInitialsAttribute(): string
    {
        $name = $this->full_name;
        $words = explode(' ', $name);
        $initials = '';

        foreach ($words as $word) {
            $initials .= strtoupper(substr($word, 0, 1));
        }

        return substr($initials, 0, 2);
    }

    // Methods
    public function isAdmin(): bool
    {
        return (bool) ($this->is_admin ?? false);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isSuspended(): bool
    {
        return $this->status === 'suspended';
    }

    public function canLogin(): bool
    {
        return $this->isActive() && !$this->isBanned();
    }

    public function isBanned(): bool
    {
        return $this->status === 'banned';
    }

    public function isStaff(): bool
    {
        return $this->is_admin;
    }

    public function hasAnyRole(array $roles): bool
    {
        // Simple role check based on is_admin flag
        if (in_array('admin', $roles) && $this->is_admin) {
            return true;
        }
        if (in_array('user', $roles)) {
            return true;
        }
        return false;
    }

    public function hasActiveServices(): bool
    {
        return $this->getActiveServicesCount() > 0;
    }

    public function updateLastLogin(): void
    {
        $this->update(['last_login_at' => now()]);
    }

    public function addCredit(float $amount, string $description = ''): void
    {
        $balanceBefore = (float) $this->credit_balance;
        $this->increment('credit_balance', $amount);

        // Record credit transaction
        $this->creditTransactions()->create([
            'amount' => $amount,
            'type' => 'add',
            'description' => $description,
            'balance_before' => $balanceBefore,
            'balance_after' => $balanceBefore + $amount,
        ]);
    }

    public function deductCredit(float $amount, string $description = ''): bool
    {
        if ($this->credit_balance < $amount) {
            return false;
        }

        $balanceBefore = (float) $this->credit_balance;
        $this->decrement('credit_balance', $amount);

        // Record credit transaction
        $this->creditTransactions()->create([
            'amount' => -$amount,
            'type' => 'deduct',
            'description' => $description,
            'balance_before' => $balanceBefore,
            'balance_after' => $balanceBefore - $amount,
        ]);

        return true;
    }

    public function getFullName(): string
    {
        return trim("{$this->first_name} {$this->last_name}") ?: $this->name;
    }

    public function getFormattedAddress(): string
    {
        $parts = array_filter([
            $this->address_line1,
            $this->address_line2,
            trim("{$this->city}, {$this->state} {$this->postal_code}"),
            $this->country,
        ]);

        return implode("\n", $parts);
    }
}
