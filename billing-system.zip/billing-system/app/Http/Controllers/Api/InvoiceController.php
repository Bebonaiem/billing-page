<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Services\Billing\InvoiceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $invoices = $request->user()
            ->invoices()
            ->with('items')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($invoices);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $invoice = Invoice::where('user_id', $request->user()->id)
            ->with(['items', 'payments'])
            ->findOrFail($id);

        return response()->json($invoice);
    }

    public function pay(Request $request, int $id): JsonResponse
    {
        $invoice = Invoice::where('user_id', $request->user()->id)
            ->findOrFail($id);

        if ($invoice->status === 'paid') {
            return response()->json(['error' => 'Invoice already paid'], 400);
        }

        $validated = $request->validate([
            'payment_method' => 'required|string',
            'gateway_id' => 'nullable|exists:payment_gateways,id',
        ]);

        $invoice->addPayment(
            (float) $invoice->balance,
            $validated['payment_method']
        );

        return response()->json($invoice->fresh()->load(['items', 'payments']));
    }

    public function adminIndex(Request $request): JsonResponse
    {
        $query = Invoice::with(['user', 'items']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $invoices = $query->orderBy('created_at', 'desc')->paginate(20);

        return response()->json($invoices);
    }

    public function markPaid(Request $request, int $id): JsonResponse
    {
        $invoice = Invoice::findOrFail($id);

        $invoiceService = new InvoiceService();
        $invoiceService->markAsPaid($invoice);

        return response()->json($invoice->fresh()->load(['items', 'payments']));
    }
}
