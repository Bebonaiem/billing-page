<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\Order\OrderService;
use App\Services\Cart\CartService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $orders = $request->user()
            ->orders()
            ->with(['items.product', 'services'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($orders);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'coupon_code' => 'nullable|string',
        ]);

        try {
            $orderService = new OrderService();
            $order = $orderService->createFromCart(
                $request->user()->id,
                $validated['coupon_code'] ?? null
            );

            return response()->json($order->load('items'), 201);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $order = Order::where('user_id', $request->user()->id)
            ->with(['items.product', 'services', 'invoice'])
            ->findOrFail($id);

        return response()->json($order);
    }

    public function activate(Request $request, int $id): JsonResponse
    {
        $order = Order::findOrFail($id);

        try {
            $orderService = new OrderService();
            $orderService->activateOrder($order);

            return response()->json($order->fresh()->load('items', 'services'));
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $order = Order::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $orderService = new OrderService();
        $orderService->cancelOrder($order, 'immediate', $request->input('reason', ''));

        return response()->json($order->fresh());
    }

    public function adminIndex(Request $request): JsonResponse
    {
        $query = Order::with(['user', 'items', 'services']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $orders = $query->orderBy('created_at', 'desc')->paginate(20);

        return response()->json($orders);
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required|in:pending,active,suspended,cancelled,terminated',
        ]);

        $order->update(['status' => $validated['status']]);

        return response()->json($order->fresh());
    }
}
