<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $services = $request->user()
            ->services()
            ->with(['product', 'order'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($services);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $service = Service::where('user_id', $request->user()->id)
            ->with(['product', 'order'])
            ->findOrFail($id);

        return response()->json($service);
    }

    public function upgrade(Request $request, int $id): JsonResponse
    {
        $service = Service::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $validated = $request->validate([
            'product_id' => 'required|exists:products,id',
        ]);

        $service->update(['product_id' => $validated['product_id']]);

        return response()->json($service->fresh()->load('product'));
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $service = Service::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $validated = $request->validate([
            'type' => 'nullable|in:immediate,end_of_term',
            'reason' => 'nullable|string|max:500',
        ]);

        $service->cancel(
            $validated['type'] ?? 'immediate',
            $validated['reason'] ?? null
        );

        return response()->json($service->fresh());
    }

    public function adminIndex(Request $request): JsonResponse
    {
        $query = Service::with(['user', 'product', 'order']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $services = $query->orderBy('created_at', 'desc')->paginate(20);

        return response()->json($services);
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $service = Service::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required|in:active,suspended,cancelled,terminated',
        ]);

        match ($validated['status']) {
            'active' => $service->activate(),
            'suspended' => $service->suspend(),
            'terminated' => $service->terminate(),
            'cancelled' => $service->cancel(),
        };

        return response()->json($service->fresh());
    }
}
