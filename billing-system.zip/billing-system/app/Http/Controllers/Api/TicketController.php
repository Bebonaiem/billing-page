<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\TicketReply;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tickets = $request->user()
            ->tickets()
            ->with(['department', 'replies'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($tickets);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'department_id' => 'required|exists:ticket_departments,id',
            'service_id' => 'nullable|exists:services,id',
            'priority' => 'required|in:low,medium,high,critical',
            'message' => 'required|string|min:10',
        ]);

        $ticket = Ticket::create([
            'user_id' => $request->user()->id,
            'department_id' => $validated['department_id'],
            'service_id' => $validated['service_id'] ?? null,
            'subject' => $validated['subject'],
            'priority' => $validated['priority'],
            'status' => 'open',
        ]);

        $ticket->replies()->create([
            'user_id' => $request->user()->id,
            'message' => $validated['message'],
            'is_staff_reply' => false,
            'is_internal_note' => false,
        ]);

        return response()->json($ticket->load('replies', 'department'), 201);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $ticket = Ticket::where('user_id', $request->user()->id)
            ->with(['replies.user', 'replies.attachments', 'department'])
            ->findOrFail($id);

        return response()->json($ticket);
    }

    public function reply(Request $request, int $id): JsonResponse
    {
        $ticket = Ticket::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $validated = $request->validate([
            'message' => 'required|string|min:5',
        ]);

        $reply = $ticket->replies()->create([
            'user_id' => $request->user()->id,
            'message' => $validated['message'],
            'is_staff_reply' => false,
            'is_internal_note' => false,
        ]);

        $ticket->update(['status' => 'customer_reply']);

        return response()->json($reply->load('user'), 201);
    }

    public function close(Request $request, int $id): JsonResponse
    {
        $ticket = Ticket::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $ticket->update(['status' => 'closed']);

        return response()->json($ticket);
    }

    public function adminIndex(Request $request): JsonResponse
    {
        $query = Ticket::with(['user', 'department', 'replies']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $tickets = $query->orderBy('created_at', 'desc')->paginate(20);

        return response()->json($tickets);
    }

    public function adminReply(Request $request, int $id): JsonResponse
    {
        $ticket = Ticket::findOrFail($id);

        $validated = $request->validate([
            'message' => 'required|string|min:5',
            'is_internal_note' => 'nullable|boolean',
        ]);

        $reply = $ticket->replies()->create([
            'user_id' => $request->user()->id,
            'message' => $validated['message'],
            'is_staff_reply' => true,
            'is_internal_note' => $validated['is_internal_note'] ?? false,
        ]);

        $ticket->update(['status' => 'answered']);

        return response()->json($reply->load('user'), 201);
    }
}
