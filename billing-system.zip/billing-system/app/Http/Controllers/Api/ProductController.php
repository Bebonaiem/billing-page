<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $products = Product::query()
            ->visible()
            ->with(['category', 'configOptions.values'])
            ->orderBy('sort_order')
            ->orderBy('name')
            ->paginate(20);

        return response()->json($products);
    }

    public function show(int $id): JsonResponse
    {
        $product = Product::with(['category', 'configOptions.values'])
            ->visible()
            ->findOrFail($id);

        return response()->json($product);
    }
}
