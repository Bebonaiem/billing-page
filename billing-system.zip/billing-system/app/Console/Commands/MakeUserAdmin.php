<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class MakeUserAdmin extends Command
{
    protected $signature = 'app:make-user-admin {email : The email of the user to promote}';
    protected $description = 'Promote an existing user to administrator';

    public function handle()
    {
        $email = $this->argument('email');

        $user = User::where('email', $email)->first();

        if (!$user) {
            $this->error("User with email '{$email}' not found.");
            return 1;
        }

        if ($user->is_admin) {
            $this->warn("User '{$email}' is already an administrator.");
            return 0;
        }

        $user->is_admin = true;
        $user->save();

        $this->info("User '{$email}' has been promoted to administrator.");
        return 0;
    }
}
