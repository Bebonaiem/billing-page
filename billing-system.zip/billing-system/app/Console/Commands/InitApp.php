<?php

namespace App\Console\Commands;

use App\Models\Setting;
use Illuminate\Console\Command;

class InitApp extends Command
{
    protected $signature = 'app:init';
    protected $description = 'Initialize application settings';

    public function handle()
    {
        $this->info('Initializing Billing System application settings...');

        $settings = [
            'app_name' => ['value' => config('app.name'), 'type' => 'string'],
            'app_url' => ['value' => config('app.url'), 'type' => 'string'],
            'app_timezone' => ['value' => config('app.timezone'), 'type' => 'string'],
            'currency' => ['value' => 'USD', 'type' => 'string'],
            'invoice_prefix' => ['value' => 'INV-', 'type' => 'string'],
            'quote_prefix' => ['value' => 'QUOTE-', 'type' => 'string'],
            'ticket_prefix' => ['value' => 'TKT-', 'type' => 'string'],
            'company_name' => ['value' => config('app.name'), 'type' => 'string'],
            'company_email' => ['value' => '', 'type' => 'string'],
            'support_email' => ['value' => '', 'type' => 'string'],
            'default_currency' => ['value' => 'USD', 'type' => 'string'],
            'default_language' => ['value' => 'en', 'type' => 'string'],
            'timezone' => ['value' => 'UTC', 'type' => 'string'],
        ];

        foreach ($settings as $key => $data) {
            Setting::set($key, $data['value'], 'general', $data['type']);
            $this->line("Set {$key}");
        }

        $this->info('Application initialization complete!');
        return 0;
    }
}
